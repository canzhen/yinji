@extends('layouts.content')

@section('title','首页')

@section('header')
	@parent
	<link rel="stylesheet" type="text/css" href="/css/home.css">
@show

@section('footer')
	@parent
	

@show


@section('content')



@stop