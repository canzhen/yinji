@extends('layouts.header')

@section('title','登录成功')


@section('body')
	<h1>这里是主页</h1>
@stop