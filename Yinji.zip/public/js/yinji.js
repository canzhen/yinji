/**
 * Created by Zhou Canzhen on 2016/03/28.
 */

var yinjiApp = angular.module('yinjiApp', ['ngAnimate']);