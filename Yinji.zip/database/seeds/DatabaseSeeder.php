<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * 初始化数据
     *
     * @return void
     * @author 周灿桢
     */
    public function run()
    {
//
//        User::create(array(
//            'name' => 'zcz',
//            'privilege' => 'admin',
//            'email' => 'xdzcz@outlook.com',
//            'password' => Hash::make('123')
//        ));
//
//        User::create(array(
//            'name' => 'jp',
//            'privilege' => 'user',
//            'email' => 'jp@163.com',
//            'password' => Hash::make('123')
//        ));
//
//        User::create(array(
//            'name' => 'scx',
//            'privilege' => 'user',
//            'email' => 'scx@163.com',
//            'password' => Hash::make('123')
//        ));
//
//        User::create(array(
//            'name' => 'yhc',
//            'privilege' => 'user',
//            'email' => 'yhc95@163.com',
//            'password' => Hash::make('123')
//        ));
//
//        User::create(array(
//            'name' => 'gyf',
//            'privilege' => 'user',
//            'email' => 'gyf@163.com',
//            'password' => Hash::make('123')
//        ));

    }
}
