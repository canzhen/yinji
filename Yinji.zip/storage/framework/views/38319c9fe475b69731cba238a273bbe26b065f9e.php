<?php $__env->startSection('title','登录成功'); ?>


<?php $__env->startSection('body'); ?>
	<h1>这里是主页</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>