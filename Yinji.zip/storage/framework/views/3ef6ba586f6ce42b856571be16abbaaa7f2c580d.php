<!DOCTYPE html>
<html>

    <head>
        <title><?php echo $__env->yieldContent('title'); ?> - 印迹</title>
        <?php $__env->startSection('header'); ?>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
            <link rel="stylesheet" href="/css/lib/bootstrap/bootstrap.min.css">
            <link rel="stylesheet" href="/css/lib/bootstrap/bootstrap-theme.min.css">
            <link rel="stylesheet" href="/css/lib/fontAwesome/css/font-awesome.css">
			<link rel='stylesheet' href="/css/lib/myfont.css"/>
            <link rel="stylesheet" href="/css/content.css"  type="text/css" media="all"/>
        <?php echo $__env->yieldSection(); ?>
        
    </head>
	
	
    <body ng-app="yinjiApp">
        <?php $__env->startSection('body'); ?>
        <?php echo $__env->yieldSection(); ?>
        <?php $__env->startSection('footer'); ?>
            <script src="/js/lib/jquery.min.js"></script>
            <script src="/js/lib/angularjs/angular.min.js"></script>
            <script src="/js/lib/angularjs/angular-animate.min.js"></script>
            <script src="/js/lib/angularjs/angular-route.min.js"></script>
            <script src="/js/yinji.js"></script>
            <script src="/js/lib/bootstrap.min.js"></script>
        <?php echo $__env->yieldSection(); ?>
    </body>
</html>
