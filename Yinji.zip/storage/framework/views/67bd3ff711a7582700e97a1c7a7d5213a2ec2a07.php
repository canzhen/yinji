<?php $__env->startSection('title','首页'); ?>

<?php $__env->startSection('header'); ?>
	@parent
	<link href="/css/index.css" rel="stylesheet" type="text/css" media="all"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	@parent
	<script src="/js/index.js"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="slider">
	    <div class="callbacks_container">
		    <ul class="rslides" id="slider">
		        <li>
			        <div class="banner"></div>
		        </li>

		        <li>
			        <div class="banner1"></div>
		        </li>

		        <li>
			        <div class="banner2"></div>
		        </li>
		    </ul>
		</div>
    </div>
	<!--幻灯片区域结束-->

	<div id="small-dialog5" class="mfp-hide"></div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>