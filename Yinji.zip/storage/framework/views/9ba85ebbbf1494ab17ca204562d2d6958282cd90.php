<?php $__env->startSection('title','注册'); ?>

<?php $__env->startSection('header'); ?>
	@parent
	<link href="/css/register.css" rel='stylesheet' type='text/css'/>
<?php echo $__env->yieldSection(); ?>

<?php $__env->startSection('footer'); ?>
	@parent
	<script src="/js/register.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('auth'); ?>

	<form ng-submit="register()">
		<div class="gbkt" >
			<input type="text" style="font-size:16px;"
				   placeholder="请输入用户名" ng-blur="checkUserExist()" ng-model="username">
			<input type="password" style="font-size:16px;"
				   placeholder="请输入密码" ng-model="pwd">
			<input type="password" style="font-size:16px;"
				   placeholder="请再次输入密码" ng-model="repwd">
		</div>

		<div class="errMsg gbkt" style="color:{{errMsgColor}}">
			{{errMsg}}
		</div>

		</br></br>
		<div class="signin">
			<input type="submit" class="gbxs login-font" value="注册" >
		</div>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>