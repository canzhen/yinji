<?php $__env->startSection('title','首页'); ?>

<?php $__env->startSection('header'); ?>
	@parent
	<link rel="stylesheet" type="text/css" href="/css/home.css">
<?php echo $__env->yieldSection(); ?>

<?php $__env->startSection('footer'); ?>
	@parent
	

<?php echo $__env->yieldSection(); ?>


<?php $__env->startSection('content'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>